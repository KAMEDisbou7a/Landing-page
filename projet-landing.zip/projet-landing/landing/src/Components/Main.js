import React from "react";

const Main = () => {
  return (
    <div className="main">
      <div className="col col1">
        <div className="image-container">
          <div className="text-container">
            <h2>Improve your skills on your own <br/>To prepare for a better future</h2>
            <div className="btn">
              <button type="button">Login</button>
            </div>
          </div>
        </div>
        <div className="discover-container">
          <h3>Discover our courses</h3>
          <button type="button">View More</button>
        </div>
      </div>
      <div className="col">
        <div className="row">
          <div className="card">
            <img src="" alt="" />
            <h3>Title 1</h3>
          </div>
          <div className="card">
            <img src="" alt="Card 2" />
            <h3>Title 2</h3>
          </div>
        </div>
        <div className="row">
          <div className="card">
            <img src="path_to_image3.jpg" alt="Card 3" />
            <h3>Title 3</h3>
          </div>
          <div className="card">
            <img src="path_to_image4.jpg" alt="Card 4" />
            <h3>Title 4</h3>
          </div>
        </div>
        <div className="row">
          <div className="card">
            <img src="path_to_image5.jpg" alt="Card 5" />
            <h3>Title 5</h3>
          </div>
          <div className="card">
            <img src="path_to_image6.jpg" alt="Card 6" />
            <h3>Title 6</h3>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Main;
