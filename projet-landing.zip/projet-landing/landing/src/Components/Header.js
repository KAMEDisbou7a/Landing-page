import React from "react";

const Header = () => {
    return(
        <div className="header">
            <div className="logo"></div>
            <nav className="navigation">
                <ul>
                    <li><a href="/">Events</a></li>
                </ul>
            </nav>
        </div>
    );
}
export default Header;